class QuerySdkError(Exception):
    """
    Base class for all custom exceptions
    """

    def __init__(self, error_code: str, info: str, req_id: str = None):
        self._error_code = error_code
        self._info = info
        self._req_id = req_id

    def __str__(self):
        return '{}[{}]-{}: {}'.format(self.__class__.__name__, self._req_id,
            self._error_code, self._info)

    @property
    def error_code(self):
        return self._error_code

    @property
    def info(self):
        return self._info

    @property
    def req_id(self):
        return self._req_id
