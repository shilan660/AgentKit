from typing import List

from dpquerycore.enums import FieldType


class Field(object):
    def __init__(self, name: str, field_type: str):
        self._name = name
        self._raw_field_type = field_type
        self._field_type = FieldType.from_str(field_type)

    @property
    def name(self) -> str:
        return self._name

    @property
    def field_type(self) -> FieldType:
        return self._field_type

    @property
    def raw_type(self) -> str:
        return self._raw_field_type

    def __str__(self) -> str:
        return f"Field(name={self.name}, field_type={self.field_type})"


class Schema(object):
    def __init__(self, fields: List[Field]):
        self._fields = fields
        _name_to_index = {}
        for idx, field in enumerate(fields):
            _name_to_index[field.name] = idx
        self._name_to_index = _name_to_index

    def __iter__(self):
        return self._fields.__iter__()

    @property
    def fields(self):
        return self._fields

    def get_field(self, field_name: str):
        assert field_name in self._name_to_index, 'There\'s no fields with name [%s]' % field_name
        return self._fields[self._name_to_index[field_name]]

    def __str__(self) -> str:
        return f"Schema(fields={self.fields})"


class Result(object):
    default_encoding = 'utf-8'

    def __init__(self, rows: list, schema: Schema):
        self._rows = rows
        self._schema = schema
        self._total = len(rows)

    def __iter__(self):
        return self._rows.__iter__()

    @property
    def total(self):
        return self._total

    @property
    def schema(self) -> Schema:
        return self._schema

    @property
    def data(self):
        return self._rows
