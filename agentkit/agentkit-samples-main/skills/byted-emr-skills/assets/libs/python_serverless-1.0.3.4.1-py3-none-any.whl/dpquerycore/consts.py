# -*- coding: utf-8 -*-

class Constants:
    # region
    REGION_CN_BEIJING = 'cn-beijing'
    REGION_CN_SHANGHAI = 'cn-shanghai'
    REGION_CN_SHANGHAI = 'cn-guangzhou'

    # service
    SERVICE_LAS = 'las'
    SERVICE_EMR_SERVERLESS = 'emr_serverless'
    SERVICE_EMR_SERVERLESS_RD = 'emr_serverless_rd'
    SERVICE_EMR_SERVERLESS_QA = 'emr_serverless_qa'
    SERVICE_EMR_SERVERLESS_BASELINE = 'emr_serverless_baseline'

    # TOP
    TOP_ENDPOINT = 'open.volcengineapi.com'
    TOP_INTERNAL_ENDPOINT = 'volcengineapi.byted.org'

    # http client
    CONNECTION_TIMEOUT = 60
    SOCKET_TIMEOUT = 60
    CONNECTION_POOL_CACHE_SIZE = 20
    CONNECTION_POOL_MAXIMUM_SIZE = 100
    DEFAULT_SYNC_WAIT_TIMEOUT = (2 ** 31) - 1

    # units
    MINUTE = 60
    HOUR = 60 * MINUTE
    DAY = 24 * HOUR
    KB = 1024
    MB = 1024 * KB
    GB = 1024 * MB

    # default
    LAS_SDK_USER = "las_sdk_user"
    ROW_PAGE_SIZE = 10000
    ROW_LIMIT = 1000000
    RESULT_PAGE_SIZE = 2 * MB
    RESOURCE_PAGE_SIZE = 20
    MULTIPART_UPLOAD_THRESHOLD = 100 * MB
    FILE_SIZE_LIMIT = 2 * GB

    # regex
    REGEX_RESULT_URL = "^.*/download/results/(\\d{8})/(\\d{2})/(.*)/(.*\\.csv)$"
    REGEX_K8S_RESOURCE_DEF_STRING = '^(\+|-)?(([0-9]+(\.[0-9]*)?)|(\.[0-9]+))(([KMGTPE]i)' \
                                    '|[numkMGTPE]|([eE](\+|-)?(([0-9]+(\.[0-9]*)?)|(\.[0-9]+))))?$'

    # other
    TQS_DEFAULT_APP_ID = 'PUCXX5jmOKHc7H94eAl8xCIHtnkyjkPIBQLz1zGekBJT0Gkf'
