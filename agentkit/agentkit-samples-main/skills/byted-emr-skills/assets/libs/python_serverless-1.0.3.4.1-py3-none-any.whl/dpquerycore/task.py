import json
import time
from abc import ABC, abstractmethod

from dpquerycore.conf import TaskConf
from dpquerycore.enums import EngineType, TaskType
from dpquerycore.tos_auto import ensure_tos_path, ensure_tos_paths
from dpquerycore.auth import Credentials


class Task(ABC):
    def __init__(self, name: str, query: str, conf: dict, queue: str = None, compute_group: str = None):
        self._name = name
        self._query = query
        self._conf = conf
        self._queue = queue
        self._compute_group = compute_group

        for key in self._conf:
            self._conf[key] = str(self._conf[key])

    @property
    def name(self) -> str:
        return self._name

    @property
    def query(self) -> str:
        return self._query

    @property
    def conf(self) -> dict:
        return self._conf

    @property
    @abstractmethod
    def type(self) -> TaskType:
        raise NotImplementedError("Not Implemented yet")

    @property
    def queue(self) -> str:
        return self._queue

    @property
    def compute_group(self) -> str:
        return self._compute_group

    def prepare_resources(self, credentials: Credentials, tos_bucket: str = None,
                          tos_region: str = None, tos_endpoint: str = None):
        return


class SQLTask(Task):
    """
    SparkSQL task definition class.
    """

    def __init__(self, name: str, query: str, conf: dict, skip_analysis: bool = False, queue: str = None,
                 compute_group: str = None):
        """Initializes a new instance of SparkSQL.

        Args:
            name (str): task name
            query (str): sql statement to be executed
            conf (dict): task configs, should be a plain k-v string dict
            skip_analysis (bool): whether to skip the sql analysis stage
            queue (str): queue name, specified which queue this task runs on
        """
        if name is None:
            name = 'SQLTask_%s' % time.time()
        if conf is None:
            conf = {}
        if query is None:
            raise ValueError("Missing sql query statement for SQL task.")
        self._skip_analysis = skip_analysis
        super(SQLTask, self).__init__(name, query, conf, queue, compute_group)

    @property
    def name(self) -> str:
        return self._name

    @property
    def query(self) -> str:
        return self._query

    @property
    def conf(self) -> dict:
        return self._conf

    @property
    def type(self) -> TaskType:
        return TaskType.SQL

    @property
    def is_skip_analysis(self) -> bool:
        return self._skip_analysis


class JarTask(Task):
    """
    Spark Jar task definition class.
    """

    def __init__(self,
            name: str,
            jar: str,
            main_class: str,
            main_args: list,
            depend_jars: list = [],
            files: list = [],
            archives: list = [],
            conf: dict = {},
            queue: str = None,
            compute_group: str = None):
        """Initializes a new instance of SparkJarTask.

        Args:
            name (str): task name
            jar (str): jar resource reference
            main_class (str): main class reference, e.g. com.volcengine.emr.DemoUdf
            main_arg (list)s: main class arguments
            depend_jars (list): extra jar dependencies references
            files (list): extra file dependencies references
            archives (list): extra archive dependencies references
            conf (dict): task configs, should be a plain k-v string dict
            queue (str): queue name, specified which queue this task runs on
        """
        if name is None:
            name = 'SparkJarTask_%s' % time.time()
        if conf is None:
            conf = {}
        if jar is None or main_class is None:
            raise ValueError(
                "Missing required parameters for `jar` or `main_class`")
        self._jar = jar
        self._main_class = main_class
        self._main_args = main_args
        self._depend_jars = depend_jars
        self._files = files
        self._archives = archives
        conf[TaskConf.SPARK_JAR_RESOURCE] = self._jar
        conf[TaskConf.SPARK_JAR_CLASS] = self._main_class
        conf[TaskConf.SPARK_JAR_CLASS_ARGS] = json.dumps(main_args)
        conf[TaskConf.ENGINE_TYPE] = EngineType.SparkJar.name
        if self._depend_jars:
            conf[TaskConf.SPARK_JAR_DEPEND_JARS] = json.dumps([{'fileName': f} for f in self._depend_jars])
        if self._files:
            conf[TaskConf.SPARK_JAR_DEPEND_FILES] = json.dumps([{'fileName': f} for f in self._files])
        if self._archives:
            conf[TaskConf.SPARK_JAR_DEPEND_ARCHIVES] = json.dumps([{'fileName': f} for f in self._archives])

        super(JarTask, self).__init__(name, '', conf, queue, compute_group)

    @property
    def jar(self):
        return self._jar

    @property
    def main_class(self):
        return self._main_class

    @property
    def main_args(self):
        return self._main_args

    @property
    def type(self) -> TaskType:
        return TaskType.SparkJar

    @property
    def depend_jars(self):
        return self._depend_jars

    @property
    def files(self):
        return self._files

    @property
    def archives(self):
        return self._archives

    def prepare_resources(self, credentials: Credentials, tos_bucket: str = None,
                          tos_region: str = None, tos_endpoint: str = None):
        self._jar = ensure_tos_path(self._jar, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._depend_jars = ensure_tos_paths(self._depend_jars, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._files = ensure_tos_paths(self._files, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._archives = ensure_tos_paths(self._archives, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._conf[TaskConf.SPARK_JAR_RESOURCE] = str(self._jar)
        if self._depend_jars:
            self._conf[TaskConf.SPARK_JAR_DEPEND_JARS] = json.dumps([{'fileName': f} for f in self._depend_jars])
        if self._files:
            self._conf[TaskConf.SPARK_JAR_DEPEND_FILES] = json.dumps([{'fileName': f} for f in self._files])
        if self._archives:
            self._conf[TaskConf.SPARK_JAR_DEPEND_ARCHIVES] = json.dumps([{'fileName': f} for f in self._archives])


class PySparkTask(Task):
    """
    PySpark task definition class.
    """

    def __init__(self,
            name: str,
            script: str,
            args: list,
            files: list = [],
            pyfiles: list = [],
            archives: list = [],
            depend_jars: list = [],
            conf: dict = {},
            queue: str = None,
            compute_group: str = None):
        """Initializes a new task definition instance of PySparkTask.

        Args:
            name (str): task name
            script (str): the pyspark script to run
            args (list): arguments for the pyspark script
            files (list): extra file dependencies
            pyfiles (list): extra python file dependencies
            archives (list): extra archive dependencies
            depend_jars (list): extra jar dependencies references
            conf (dict): task configs, should be a plain k-v string dict
            queue (str): queue name, specified which queue this task runs on
        """
        if name is None:
            name = 'FlinkJarTask_%s' % time.time()
        if conf is None:
            conf = {}
        if script is None or args is None:
            raise ValueError(
                "Missing required parameters for `script` or `args`")
        self._script = script
        self._args = args
        self._files = files
        self._pyfiles = pyfiles
        self._archives = archives
        self._depend_jars = depend_jars
        conf[TaskConf.SPARK_JAR_RESOURCE] = self._script
        conf[TaskConf.SPARK_JAR_CLASS] = ''
        conf[TaskConf.SPARK_JAR_CLASS_ARGS] = json.dumps(self._args)
        conf[TaskConf.ENGINE_TYPE] = EngineType.SparkJar.name
        if self._files:
            conf[TaskConf.SPARK_JAR_DEPEND_FILES] = json.dumps([{'fileName': f} for f in self._files])
        if self._pyfiles:
            conf[TaskConf.SPARK_JAR_DEPEND_PYFILES] = json.dumps([{'fileName': f} for f in self._pyfiles])
        if self._archives:
            conf[TaskConf.SPARK_JAR_DEPEND_ARCHIVES] = json.dumps([{'fileName': f} for f in self._archives])
        if self._depend_jars:
            conf[TaskConf.SPARK_JAR_DEPEND_JARS] = json.dumps([{'fileName': f} for f in self._depend_jars])

        super(PySparkTask, self).__init__(name, '', conf, queue, compute_group)

    @property
    def script(self):
        return self._script

    @property
    def args(self):
        return self._args

    @property
    def type(self) -> TaskType:
        return TaskType.SparkJar

    @property
    def pyfiles(self):
        return self._pyfiles

    @property
    def files(self):
        return self._files

    @property
    def archives(self):
        return self._archives

    @property
    def depend_jars(self):
        return self._depend_jars

    def prepare_resources(self, credentials: Credentials, tos_bucket: str = None,
                          tos_region: str = None, tos_endpoint: str = None):
        self._script = ensure_tos_path(self._script, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._files = ensure_tos_paths(self._files, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._pyfiles = ensure_tos_paths(self._pyfiles, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._archives = ensure_tos_paths(self._archives, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._depend_jars = ensure_tos_paths(self._depend_jars, credentials, bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        self._conf[TaskConf.SPARK_JAR_RESOURCE] = str(self._script)
        if self._files:
            self._conf[TaskConf.SPARK_JAR_DEPEND_FILES] = json.dumps([{'fileName': f} for f in self._files])
        if self._pyfiles:
            self._conf[TaskConf.SPARK_JAR_DEPEND_PYFILES] = json.dumps([{'fileName': f} for f in self._pyfiles])
        if self._archives:
            self._conf[TaskConf.SPARK_JAR_DEPEND_ARCHIVES] = json.dumps([{'fileName': f} for f in self._archives])
        if self._depend_jars:
            self._conf[TaskConf.SPARK_JAR_DEPEND_JARS] = json.dumps([{'fileName': f} for f in self._depend_jars])
