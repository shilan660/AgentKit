from abc import ABC
from typing import List, Callable

from dpquerycore.api_service import ApiService
from dpquerycore.auth import Credentials as ClientCredentials, Identity
from dpquerycore.conf import TaskConf
from dpquerycore.consts import Constants
from dpquerycore.enums import JobStatus, TaskType
from dpquerycore.log import LogCursor
from dpquerycore.utils import preset_interval_growth_func, sync_execute
from dpquerycore.exceptions import QuerySdkError
from dpquerycore.job import Job
from dpquerycore.result import Result, Schema, Field
from dpquerycore.task import Task
from dpquerycore.protocol import ListJob


class BaseQueryClient(ABC):
    def __init__(self, api_service: ApiService):
        self._api_service = api_service

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def execute(self, task: Task, is_sync: bool = True, polling_interval: float = None,
                timeout: float = Constants.DEFAULT_SYNC_WAIT_TIMEOUT):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            if polling_interval:
                assert polling_interval > 0, '`polling_interval` must be greater than 0'
                return self._execute(credentials, identity, task, is_sync=is_sync,
                    interval_func=lambda elapsed: polling_interval,
                    timeout=timeout)
            return self._execute(credentials, identity, task, is_sync=is_sync,
                                  timeout=timeout)

        return wrapper

    def _execute(self, credentials: ClientCredentials, identity: Identity,
                  task: Task, is_sync: bool = True,
                  interval_func: Callable[[float], float] = lambda elapsed: preset_interval_growth_func(elapsed),
                  timeout: float = Constants.DEFAULT_SYNC_WAIT_TIMEOUT) -> Job:
        task.prepare_resources(credentials,
                               tos_bucket=getattr(self, '_tos_bucket', None),
                               tos_region=getattr(self, '_tos_region', None),
                               tos_endpoint=getattr(self, '_tos_endpoint', None))
        def _async_execute() -> Job:
            if task.queue:
                task.conf[TaskConf.EXECUTE_QUEUE] = task.queue
            if task.compute_group:
                task.conf[TaskConf.SERVERLESS_COMPUTE_GROUP_NAME] = task.compute_group

            # 提交作业不需要先解析，直接提交即可
            # if task.type in (TaskType.SQL, TaskType.FlinkSQL) and not getattr(task, 'is_skip_analysis', False):
            #     self._analyze(credentials, identity, task)

            if task.type in (TaskType.FlinkSQL, TaskType.FlinkJar):
                # create job
                _job_id = self._api_service.create_query(name=task.name,
                                                         query="",
                                                         conf={},
                                                         skipDispatch=True)(
                    credentials, identity)
                # start job
                self._api_service.create_query(name=task.name, query=task.query,
                                               conf=task.conf,
                                               skipDispatch=False,
                                               jobId=_job_id)(credentials,
                                                              identity)
                return self._get_job(credentials, identity, _job_id)
            _job_id = self._api_service.create_query(name=task.name,
                                                     query=task.query,
                                                     conf=task.conf)(
                credentials, identity)
            return self._get_job(credentials, identity, _job_id)

        def _sync_execute(_timeout: float, _interval_func: Callable[[float], float]):
            _job = _async_execute()
            _job.wait_for_finished(timeout=_timeout, interval_func=_interval_func)
            return _job

        if is_sync:
            return _sync_execute(timeout, interval_func)
        else:
            return _async_execute()

    def get_job(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_job(credentials, identity, job_id)

        return wrapper

    def _get_job(self, credentials: ClientCredentials, identity: Identity,
                  job_id: str) -> Job:
        _res_obj = self._api_service.get_job(job_id=job_id)(credentials,
                                                            identity)
        return Job(_res_obj).with_client(self)\
            .with_service(self._api_service, credentials, identity)

    def get_result(self, job: Job):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_result(credentials, identity, job)

        return wrapper

    def _get_result(self, credentials: ClientCredentials, identity: Identity,
                     job: Job):
        job.refresh()
        if not job.is_finished():
            job.wait_for_finished()

        if not job.is_success():
            raise QuerySdkError('JobError',
                "Can't get query result since the given Job(%s) failed." % job.id)

        if job.task_type != TaskType.SQL:
            raise QuerySdkError('InvalidParams',
                "Only supported to get query results from a sql task")

        # 获取result schema
        _schema = BaseQueryClient._transform_to_schema_from_result_schema(
            self._api_service.get_result_schema(job.id)(credentials, identity))

        # 分页获取全部结果
        _query_result, _next_position, is_fetch_finished = [], 0, False
        _resp = self._api_service.fetch_results_by_batch(job.id, _next_position,
                                                         Constants.ROW_PAGE_SIZE, 1)(
            credentials, identity)
        _page, _next_position, is_fetch_finished = _resp.rows, _resp.position, _resp.isFinished
        _query_result += _page
        while not is_fetch_finished:
            _resp = self._api_service.fetch_results_by_batch(job.id,
                                                             _next_position,
                                                             Constants.ROW_PAGE_SIZE, 0)(
                credentials, identity)
            _page, _next_position, is_fetch_finished = _resp.rows, _resp.position, _resp.isFinished
            _query_result += _page

        return Result(_query_result, _schema)

    def cancel_job(self, job: Job):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._cancel_job(credentials, identity, job)

        return wrapper

    def _cancel_job(self, credentials: ClientCredentials, identity: Identity,
                     job: Job) -> bool:
        _job = self._get_job(credentials, identity, job.id)
        if JobStatus.is_finished(_job.status):
            # 已完成任务直接返回
            return True
        _res = self._api_service.cancel_query(job.id)(credentials, identity)
        job.refresh()
        return _res

    def analyze(self, task: Task):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._analyze(credentials, identity, task)

        return wrapper

    def _analyze(self, credentials: ClientCredentials, identity: Identity,
                  task: Task):
        _query = task.query if task.type == TaskType.SQL \
            else 'set tqs.query.engine.type=FlinkCli;\n%s' % task.query

        _result = sync_execute(submit=lambda sql: self._api_service.analyze_query(sql)(credentials, identity).AnalyzeTaskId,
            params=_query, fetch_result=lambda task_id: self._api_service.describe_analyze_query(task_id)(credentials, identity),
            check_complete=lambda result: result.Status in [JobStatus.ANALYSIS_COMPLETED.label, JobStatus.ANALYSIS_FAILED.label] and hasattr(result, 'Data')
        )
        _data = getattr(_result, 'Data', None)

        if JobStatus.from_str(
                _data.Status) != JobStatus.ANALYSIS_COMPLETED:
            raise QuerySdkError('AnalysisError', _data.Error)

    def get_submission_log(self, job: Job, limit: int = 100):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_submission_log(credentials, identity, job, limit)

        return wrapper

    def _get_submission_log(self, credentials: ClientCredentials, identity: Identity,
                     job: Job, limit: int) -> LogCursor:
        return LogCursor(
            lambda param: self._api_service.get_submission_log(job.id, param.val_1, param.val_2)(credentials, identity),
            str(limit))

    def get_driver_log(self, job: Job, limit: int = 100):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_driver_log(credentials, identity, job, limit)

        return wrapper

    def _get_driver_log(self, credentials: ClientCredentials, identity: Identity,
                     job: Job, limit: int) -> LogCursor:
        return LogCursor(
            lambda param: self._api_service.get_driver_log(job.id, param.val_1, param.val_2)(credentials, identity),
            str(limit))

    def _list_job(self, credentials: ClientCredentials, identity: Identity,
        job_id: str, job_name: str, start_time: str = "", end_time: str = "", queue: str = "", limit: int = 20, offset: int = 0) -> ListJob:
        return self._api_service.list_job(
            job_id, job_name,
            start_time, end_time,
            queue, limit, offset)(credentials, identity)

    def list_job(self, job_id: str, job_name: str, start_time: str = "", end_time: str = "", queue: str = "", limit: int = 20, offset: int = 0):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._list_job(credentials, identity, job_id,
                                  job_name, start_time, end_time, queue, limit,
                                  offset)
        return wrapper

    @staticmethod
    def _transform_to_schema_from_result_schema(
            result_schema: List[List[str]]):
        if result_schema is None or len(result_schema) == 0:
            return Schema([])

        _fields = []
        for f in result_schema:
            _fields.append(Field(f[0], f[1]))
        return Schema(_fields)

    def create_compute_group(self, queue_id: str, name: str, engine_type: str, apply_strategy: str, wait_timeout_min: int = None, settings: dict = None, description: str = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._create_compute_group(credentials, identity, queue_id, name, engine_type, apply_strategy, wait_timeout_min, settings, description)
        return wrapper

    def _create_compute_group(self, credentials: ClientCredentials, identity: Identity, queue_id: str, name: str, engine_type: str, apply_strategy: str, wait_timeout_min: int = None, settings: dict = None, description: str = None) -> str:
        if engine_type.lower() == 'ray':
            if 'workerMaxReplicas' in settings or 'workerMinReplicas' in settings:
                if 'autoScaling' not in settings or not settings['autoScaling']:
                    raise QuerySdkError('InvalidParams', "'autoScaling' must be True when 'workerMaxReplicas' is provided")
        _res = self._api_service.create_compute_group(
            name=name,
            queue_id=queue_id,
            engine_type=engine_type,
            apply_strategy=apply_strategy,
            wait_timeout_min=wait_timeout_min,
            settings=settings,
            description=description
        )(credentials, identity)
        queue_component_id = _res['QueueComponentId']
        if queue_component_id is None:
            raise QuerySdkError('InvalidParams', _res)
        return queue_component_id

    def list_compute_group(self, queue_id: str = None, queue_name: str = None, status: List[str] = None, engine_type: List[str] = None, name: str = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._list_compute_group(credentials, identity, queue_id, queue_name, status, engine_type, name)
        return wrapper

    def _list_compute_group(self, credentials: ClientCredentials, identity: Identity, queue_id: str = None, queue_name: str = None, status: List[str] = None, engine_type: List[str] = None, name: str = None):
        if not queue_id and not queue_name:
            raise QuerySdkError('InvalidParams', "Either 'queue_id' or 'queue_name' must be provided")
        
        _res = self._api_service.list_queue_component(
            queue_id=queue_id,
            queue_name=queue_name,
            status=status,
            engine_type=engine_type,
            name=name
        )(credentials, identity)
        return getattr(_res, 'Result', [])

    def get_compute_group(self, queue_id: str, compute_group_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_compute_group(credentials, identity, queue_id, compute_group_id)
        return wrapper

    def _get_compute_group(self, credentials: ClientCredentials, identity: Identity, queue_id: str, compute_group_id: str):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")

        _res = self._api_service.get_queue_component(
            queue_id=queue_id,
            component_id=compute_group_id
        )(credentials, identity)
        return getattr(_res, 'Result', None)

    def stop_compute_group(self, compute_group_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._stop_compute_group(credentials, identity, compute_group_id)
        return wrapper

    def _stop_compute_group(self, credentials: ClientCredentials, identity: Identity, compute_group_id: str):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")

        _res = self._api_service.stop_queue_component(
            component_id=compute_group_id
        )(credentials, identity)
        return self.validate_compute_group_result(_res)

    def start_compute_group(self, compute_group_id: str, apply_strategy: str, wait_timeout_min: int = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._start_compute_group(credentials, identity, compute_group_id, apply_strategy, wait_timeout_min)
        return wrapper

    def _start_compute_group(self, credentials: ClientCredentials, identity: Identity, compute_group_id: str, apply_strategy: str, wait_timeout_min: int = None):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")
        if not apply_strategy:
            raise QuerySdkError('InvalidParams', "'apply_strategy' must be provided")
        if apply_strategy == 'wait' and wait_timeout_min is None:
            raise QuerySdkError('InvalidParams', "'wait_timeout_min' must be provided when apply_strategy is 'wait'")

        _res = self._api_service.start_queue_component(
            component_id=compute_group_id,
            apply_strategy=apply_strategy,
            wait_timeout_min=wait_timeout_min
        )(credentials, identity)
        return self.validate_compute_group_result(_res)

    def delete_compute_group(self, compute_group_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._delete_compute_group(credentials, identity, compute_group_id)
        return wrapper

    def _delete_compute_group(self, credentials: ClientCredentials, identity: Identity, compute_group_id: str):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")

        _res = self._api_service.delete_queue_component(
            component_id=compute_group_id
        )(credentials, identity)
        return self.validate_compute_group_result(_res)

    @staticmethod
    def validate_compute_group_result(_res):
        is_success = _res['Success']
        if is_success is None:
            raise QuerySdkError('InvalidParams', _res)
        return is_success

    def modify_compute_group(self, queue_id: str, compute_group_id: str, name: str = None, engine_type: str = None, apply_strategy: str = None, wait_timeout_min: int = None, description: str = None, settings: dict = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._modify_compute_group(credentials, identity, queue_id, compute_group_id, name, engine_type, apply_strategy, wait_timeout_min, description, settings)
        return wrapper

    def _modify_compute_group(self, credentials: ClientCredentials, identity: Identity, queue_id: str, compute_group_id: str, name: str = None, engine_type: str = None, apply_strategy: str = None, wait_timeout_min: int = None, description: str = None, settings: dict = None):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")

        _res = self._api_service.modify_queue_component(
            queue_id=queue_id,
            component_id=compute_group_id,
            name=name,
            engine_type=engine_type,
            apply_strategy=apply_strategy,
            wait_timeout_min=wait_timeout_min,
            description=description,
            settings=settings
        )(credentials, identity)
        return self.validate_compute_group_result(_res)


    def get_compute_group_custom_conf(self, queue_id: str, compute_group_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_compute_group_custom_conf(credentials, identity, queue_id, compute_group_id)
        return wrapper

    def _get_compute_group_custom_conf(self, credentials: ClientCredentials, identity: Identity, queue_id: str, compute_group_id: str):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")

        _res = self._api_service.get_queue_component_settings(
            queue_id=queue_id,
            component_id=compute_group_id
        )(credentials, identity)
        return getattr(_res, 'Result', {})

    def update_compute_group_custom_conf(self, queue_id: str, compute_group_id: str, custom_settings: dict):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._update_compute_group_custom_conf(credentials, identity, queue_id, compute_group_id, custom_settings)
        return wrapper

    def _update_compute_group_custom_conf(self, credentials: ClientCredentials, identity: Identity, queue_id: str, compute_group_id: str, custom_settings: dict):
        if not compute_group_id:
            raise QuerySdkError('InvalidParams', "'compute_group_id' must be provided")
        if not custom_settings:
            raise QuerySdkError('InvalidParams', "'custom_settings' must be provided")

        _res = self._api_service.save_queue_component_settings(
            queue_id=queue_id,
            component_id=compute_group_id,
            custom_settings=custom_settings
        )(credentials, identity)
        return getattr(_res, 'Result', None)

    def close(self):
        self._api_service.close()
