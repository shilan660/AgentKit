from collections import namedtuple
from typing import Callable

from dpquerycore.protocol import LogResult

Tuple2 = namedtuple("Tuple2", ["val_1", "val_2"])


class LogCursor(object):
    def __init__(self, fetch_log_api: Callable[[Tuple2], LogResult], limit: str = '100'):
        self.fetch_log_api = fetch_log_api
        self.position = '0'
        self.limit = limit
        self.is_finished = False
        self.current_rows = []

    def fetch_next_page(self):
        if self.is_finished:
            return
        _log = self.fetch_log_api(Tuple2(self.position, self.limit))
        if _log is not None:
            self.current_rows = _log.Rows
            self.position = _log.Position
            self.is_finished = _log.IsFinished

    def has_next(self):
        return not self.is_finished

    def reset(self):
        self.position = '0'
        self.is_finished = False
        self.current_rows = []
