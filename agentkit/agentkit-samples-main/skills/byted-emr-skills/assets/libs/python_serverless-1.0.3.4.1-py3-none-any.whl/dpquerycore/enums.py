import enum
from enum import Enum, auto


class CredentialsType(Enum):
    STATIC = auto()
    DYNAMIC_TOKEN = auto()


class EngineType(Enum):
    Hive = auto()
    Presto = auto()
    Spark = auto()
    SparkCli = auto()
    FlinkCli = auto()
    FlinkJar = auto()
    SparkJar = auto()
    RayJob = auto()

    @staticmethod
    def from_str(engine_type: str):
        for e in EngineType:
            if e.name.lower() == engine_type.lower():
                return e
        raise TypeError("Invalid EngineType")


class TaskType(Enum):
    Unknown = auto()
    SQL = auto()
    SparkJar = auto()
    FlinkSQL = auto()
    FlinkJar = auto()
    RayJob = auto()

    @staticmethod
    def from_engine(engine_type: EngineType):
        if engine_type in (
                EngineType.Presto, EngineType.Spark, EngineType.SparkCli):
            return TaskType.SQL
        elif engine_type == EngineType.SparkJar:
            return TaskType.SparkJar
        elif engine_type == EngineType.FlinkCli:
            return TaskType.FlinkSQL
        elif engine_type == EngineType.FlinkJar:
            return TaskType.FlinkJar
        elif engine_type == EngineType.RayJob:
            return TaskType.RayJob
        else:
            return TaskType.Unknown


class ErrorCode(Enum):
    INVALID_FILE = auto()
    JOB_ERROR = auto()
    RESOURCE_ERROR = auto()
    SERVER_INTERNAL_ERROR = auto()
    PERMISSION_DENIED = auto()
    RESULT_ERROR = auto()
    ANALYSIS_ERROR = auto()
    INVALID_CREDENTIALS_ERROR = auto()
    RESOURCE_NOT_FOUND_ERROR = auto()
    UNEXPECTED_ERROR = auto()
    CLIENT_ERROR = auto()


class JobStatus(enum.Enum):

    def __new__(cls, *args, **kwds):
        value = len(cls.__members__) + 1
        obj = object.__new__(cls)
        obj._value_ = value
        return obj

    def __init__(self, label):
        self._label = label

    CREATED = "Created"
    ANALYSIS_COMPLETED = "AnalysisCompleted"
    ANALYSIS_FAILED = "AnalysisFailed"
    DISPATCHED = "Dispatched"
    SCHEDULED = "Scheduled"
    PENDING = "Pending"
    MATCHED = "Matched"
    PROCESSING = "Processing"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"
    FAILED = "Failed"
    FALLBACK = "Fallback"

    @property
    def label(self):
        return self._label

    @staticmethod
    def from_str(status: str):
        for e in JobStatus:
            if e.label.lower() == status.lower():
                return e
        raise TypeError("Invalid JobStatus")

    @staticmethod
    def is_finished(status: 'JobStatus'):
        return status in (
            JobStatus.ANALYSIS_FAILED, JobStatus.COMPLETED, JobStatus.CANCELLED,
            JobStatus.FAILED)

    @staticmethod
    def is_failed(status: 'JobStatus'):
        return status in (JobStatus.ANALYSIS_FAILED, JobStatus.FAILED)

    @staticmethod
    def is_success(status: 'JobStatus'):
        return status == JobStatus.COMPLETED


class IdentityType(Enum):
    Account = auto()
    User = auto()


class SQLType(Enum):
    DML = auto()
    DDL = auto()
    DQL = auto()
    UNKNOWN = auto()

    @staticmethod
    def from_str(sql_type: str):
        for e in SQLType:
            if e.name.lower() == sql_type.lower():
                return e
        raise TypeError("Invalid SQLType")


class FieldType(enum.Enum):

    def __new__(cls, *args, **kwds):
        value = len(cls.__members__) + 1
        obj = object.__new__(cls)
        obj._value_ = value
        return obj

    def __init__(self, raw_types: list):
        self._raw_types = raw_types

    @property
    def raw_types(self):
        return self._raw_types

    INT = ['INT', 'INTEGER']
    TINYINT = ['TINYINT']
    SMALLINT = ['SMALLINT']
    SHORT = ['SHORT']
    BIGINT = ['BIGINT']
    FLOAT = ['FLOAT']
    DOUBLE = ['DOUBLE']
    DECIMAL = ['DECIMAL']
    NUMERIC = ['NUMERIC']
    CHAR = ['CHAR']
    VARCHAR = ['VARCHAR']
    STRING = ['STRING']
    BINARY = ['VARBINARY', 'BINARY']
    BOOLEAN = ['BOOL', 'BOOLEAN']
    DATE = ['DATE']
    TIMESTAMP = ['TIMESTAMP']
    INTERVAL = ['INTERVAL']
    ARRAY = ['ARRAY']
    MAP = ['MAP']
    STRUCT = ['STRUCT']
    UNION = ['UNION']
    NULL = ['NULL']
    UNCATEGORIZED = []

    @staticmethod
    def from_str(field_type: str):
        assert field_type, 'The input field type string can\'t be null'

        for e in FieldType:
            for rt in e.raw_types:
                if field_type.upper().startswith(rt):
                    return e
        return FieldType.UNCATEGORIZED
