import json

from volcengine.ApiInfo import ApiInfo

from dpquerycore.api_service import ApiService
from dpquerycore.auth import Credentials as ClientCredentials, Identity
from dpquerycore.consts import Constants
from typing import List, Optional
from dpquerycore.protocol import *

_serverless_api_dict = {
    "GetQueueComponentSettings": ApiInfo("GET", "/", {"Action": "GetQueueComponentSettings",
        "Version": "2024-03-25"}, {},
        {}),
    "SaveQueueComponentSettings": ApiInfo("POST", "/", {"Action": "SaveQueueComponentSettings",
        "Version": "2024-03-25"}, {},
        {}),
    "QueryGetJobV2": ApiInfo("GET", "/", {"Action": "QueryGetJobV2",
        "Version": "2024-03-25"}, {},
        {}),
    "QueryCreateQuery": ApiInfo("POST", "/",
        {"Action": "QueryCreateQuery",
            "Version": "2024-03-25"}, {}, {}),
    "QueryExplainQuery": ApiInfo("POST", "/",
        {"Action": "QueryExplainQuery",
            "Version": "2024-03-25"}, {}, {}),
    "QueryDescribeExplainQuery": ApiInfo("GET", "/",
        {"Action": "QueryDescribeExplainQuery",
            "Version": "2024-03-25"}, {}, {}),
    "QueryCancelQueryV2": ApiInfo("POST", "/",
        {"Action": "QueryCancelQueryV2",
            "Version": "2024-03-25"}, {}, {}),
    "QueryGetQueryResult": ApiInfo("GET", "/",
        {"Action": "QueryGetQueryResult",
            "Version": "2024-03-25"}, {}, {}),
    "QueryDownloadResults": ApiInfo("GET", "/",
        {"Action": "QueryDownloadResults",
            "Version": "2024-03-25"}, {}, {}),
    "QueryGetResultSchema": ApiInfo("GET", "/",
        {"Action": "QueryGetResultSchema",
            "Version": "2024-03-25"}, {}, {}),
    "QueryGetTrackingURL": ApiInfo("GET", "/",
        {"Action": "QueryGetTrackingURL",
            "Version": "2024-03-25"}, {}, {}),
    "QueryCheckJobStatus": ApiInfo("GET", "/",
        {"Action": "QueryCheckJobStatus",
            "Version": "2024-03-25"}, {}, {}),
    "QueryGetResultUrl": ApiInfo("GET", "/",
        {"Action": "QueryGetResultUrl",
            "Version": "2024-03-25"}, {}, {}),
    "QueryFetchResultsByBatch": ApiInfo("GET", "/",
        {
            "Action": "QueryFetchResultsByBatch",
            "Version": "2024-03-25"},
        {}, {}),
    "QueryFetchSubmitLog": ApiInfo("GET", "/",
        {
            "Action": "QueryFetchSubmitLog",
            "Version": "2024-03-25"},
        {}, {}),
    "QueryFetchDriverLog": ApiInfo("GET", "/",
        {
            "Action": "QueryFetchDriverLog",
            "Version": "2024-03-25"},
        {}, {},),
    "ListJobInstances": ApiInfo("GET", "/",
        {
            "Action": "ListJobInstances",
            "Version": "2024-03-25"},
        {}, {},),
    "ListJob": ApiInfo("GET", "/",
        {
            "Action": "ListJob",
            "Version": "2024-03-25"},
        {}, {},),
    "CreateQueueComponent": ApiInfo("POST", "/",
        {
            "Action": "CreateQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {}),
    "GetQueueComponent": ApiInfo("GET", "/",
        {
            "Action": "GetQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {}),
    "ModifyQueueComponent": ApiInfo("POST", "/",
        {
            "Action": "ModifyQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {}),
    "DeleteQueueComponent": ApiInfo("POST", "/",
        {
            "Action": "DeleteQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {}),
    "ListQueueComponent": ApiInfo("POST", "/",
        {
            "Action": "ListQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {}),
    "StartQueueComponent": ApiInfo("POST", "/",
        {
            "Action": "StartQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {}),
    "StopQueueComponent": ApiInfo("POST", "/",
        {
            "Action": "StopQueueComponent",
            "Version": "2024-03-25"}, 
        {}, {})
}


class ServerlessService(ApiService):
    def __init__(self, endpoint: str = Constants.TOP_ENDPOINT,
            service: str = Constants.SERVICE_EMR_SERVERLESS,
            region: str = Constants.REGION_CN_BEIJING,
            scheme: str = 'https',
            connection_timeout: int = Constants.CONNECTION_TIMEOUT,
            socket_timeout: int = Constants.SOCKET_TIMEOUT):
        super().__init__(api_dict=_serverless_api_dict, endpoint=endpoint, service=service,
            region=region, scheme=scheme, connection_timeout=connection_timeout,
            socket_timeout=socket_timeout)

    def get_job(self, job_id: str):
        return super().get_job(job_id)

    def create_query(self, name: str, query: str, conf: dict, **kwargs):
        return super().create_query(name, query, conf, **kwargs)

    def cancel_query(self, job_id: str):
        return super().cancel_query(job_id)

    def analyze_query(self, sql: str):
        return super().analyze_query(sql)

    def describe_analyze_query(self, analyze_task_id: str):
        return super().describe_analyze_query(analyze_task_id)

    def get_query_result(self, job_id: str):
        return super().get_query_result(job_id)

    def download_results(self, url: str, offset: int, limit: int):
        return super().download_results(url, offset, limit)

    def fetch_results_by_batch(self, job_id: str, position: int, limit: int, skip_lines: int = 0):
        return super().fetch_results_by_batch(job_id, position, limit, skip_lines)

    def get_result_schema(self, job_id: str):
        return super().get_result_schema(job_id)

    def get_tracking_url(self, job_id: str):
        return super().get_tracking_url(job_id)

    def get_result_url(self, job_id: str):
        return super().get_result_url(job_id)

    def get_submission_log(self, job_id: str, position: str, limit: str):
        return super().get_submission_log(job_id, position, limit)

    def get_driver_log(self, job_id: str, position: str, limit: str):
        return super().get_driver_log(job_id, position, limit)

    def list_job(self, job_id: str, job_name: str = 0, start_time: str = "", end_time: str = "",
        queue: str = "", limit: int = 20, offset: int = 0):
        return super().list_job(job_id, job_name, start_time, end_time, queue, limit, offset)

    def create_compute_group(self, queue_id: str, name: str, engine_type: str, apply_strategy: str, 
            wait_timeout_min: int = None, description: str = None, settings: str = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._create_compute_group(credentials, identity, name, queue_id, engine_type, 
                apply_strategy, wait_timeout_min, description, settings)

        return wrapper

    def _create_compute_group(self, credentials: ClientCredentials, identity: Identity, 
            name: str, queue_id: str, engine_type: str, apply_strategy: str, 
            wait_timeout_min: int = None, description: str = None, settings: str = None) -> bool:
        _api = self._get_api('CreateQueueComponent')
        _body = {
            'Name': name,
            'QueueId': queue_id,
            'EngineType': engine_type,
            'ApplyStrategy': apply_strategy,
        }

        if wait_timeout_min is not None:
            _body['WaitTimeoutMin'] = wait_timeout_min
        if description is not None:
            _body['Description'] = description
        if settings is not None:
            _body['Settings'] = json.dumps(settings)

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, CreateQueueComponentResponse).Result

    def list_queue_component(self, queue_id: str = None, queue_name: str = None, status: List[str] = None, 
            engine_type: List[str] = None, name: str = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._list_queue_component(credentials, identity, queue_id, queue_name, status, 
                engine_type, name)

        return wrapper

    def _list_queue_component(self, credentials: ClientCredentials, identity: Identity, 
            queue_id: str = None, queue_name: str = None, status: List[str] = None, 
            engine_type: List[str] = None, name: str = None):
        _api = self._get_api('ListQueueComponent')
        _body = {}

        if queue_id is not None:
            _body['QueueId'] = queue_id
        if queue_name is not None:
            _body['QueueName'] = queue_name
        if status is not None:
            _body['Status'] = status
        if engine_type is not None:
            _body['EngineType'] = engine_type
        if name is not None:
            _body['Name'] = name

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, ListQueueComponentResponse)

    def get_queue_component(self, queue_id: str, component_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_queue_component(credentials, identity, queue_id, component_id)

        return wrapper

    def _get_queue_component(self, credentials: ClientCredentials, identity: Identity, 
            queue_id: str, component_id: str):
        _api = self._get_api('GetQueueComponent')
        _body = {
            'QueueId': queue_id,
            'ComponentId': component_id
        }

        _res = self._api_service.get(_api, _body, credentials, identity)
        return self._validate_and_parse_response(_api, _res, GetQueueComponentResponse)

    def stop_queue_component(self, component_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._stop_queue_component(credentials, identity, component_id)

        return wrapper

    def _stop_queue_component(self, credentials: ClientCredentials, identity: Identity, component_id: str):
        _api = self._get_api('StopQueueComponent')
        _body = {
            'Id': component_id
        }

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, StopQueueComponentResponse).Result

    def start_queue_component(self, component_id: str, apply_strategy: str, wait_timeout_min: int = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._start_queue_component(credentials, identity, component_id, apply_strategy, wait_timeout_min)

        return wrapper

    def _start_queue_component(self, credentials: ClientCredentials, identity: Identity, component_id: str, apply_strategy: str, wait_timeout_min: int = None):
        _api = self._get_api('StartQueueComponent')
        _body = {
            'Id': component_id,
            'ApplyStrategy': apply_strategy
        }

        if apply_strategy == 'wait' and wait_timeout_min is not None:
            _body['WaitTimeoutMin'] = wait_timeout_min

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, StartQueueComponentResponse).Result

    def delete_queue_component(self, component_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._delete_queue_component(credentials, identity, component_id)

        return wrapper

    def _delete_queue_component(self, credentials: ClientCredentials, identity: Identity, component_id: str):
        _api = self._get_api('DeleteQueueComponent')
        _body = {
            'Id': component_id
        }

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, DeleteQueueComponentResponse).Result

    def modify_queue_component(self, queue_id: str, component_id: str, name: str = None, engine_type: str = None, apply_strategy: str = None, wait_timeout_min: int = None, description: str = None, settings: dict = None):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._modify_queue_component(credentials, identity, queue_id, component_id, name, engine_type, apply_strategy, wait_timeout_min, description, settings)

        return wrapper

    def _modify_queue_component(self, credentials: ClientCredentials, identity: Identity, queue_id: str, component_id: str, name: str = None, engine_type: str = None, apply_strategy: str = None, wait_timeout_min: int = None, description: str = None, settings: dict = None):
        _api = self._get_api('ModifyQueueComponent')
        _body = {
            'QueueId': queue_id,
            'Id': component_id
        }

        if name is not None:
            _body['Name'] = name
        if engine_type is not None:
            _body['EngineType'] = engine_type
        if apply_strategy is not None:
            _body['ApplyStrategy'] = apply_strategy
        if wait_timeout_min is not None:
            _body['WaitTimeoutMin'] = wait_timeout_min
        if description is not None:
            _body['Description'] = description
        if settings is not None:
            _body['Settings'] = json.dumps(settings)

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, ModifyQueueComponentResponse).Result

    def get_queue_component_settings(self, queue_id: str, component_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_queue_component_settings(credentials, identity, queue_id, component_id)

        return wrapper

    def _get_queue_component_settings(self, credentials: ClientCredentials, identity: Identity, queue_id: str, component_id: str):
        _api = self._get_api('GetQueueComponentSettings')
        _body = {
            'QueueId': queue_id,
            'ComponentId': component_id
        }

        _res = self._api_service.get(_api, _body, credentials, identity)
        return self._validate_and_parse_response(_api, _res, GetQueueComponentSettingsResponse)

    def save_queue_component_settings(self, queue_id: str, component_id: str, custom_settings: dict):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._save_queue_component_settings(credentials, identity, queue_id, component_id, custom_settings)

        return wrapper

    def _save_queue_component_settings(self, credentials: ClientCredentials, identity: Identity, queue_id: str, component_id: str, custom_settings: dict):
        if not custom_settings:
            raise QuerySdkError('InvalidParams', "'custom_settings' must be provided")

        _api = self._get_api('SaveQueueComponentSettings')
        _body = {
            'QueueId': queue_id,
            'ComponentId': component_id,
            'CustomSettings': custom_settings
        }

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials, identity)
        return self._validate_and_parse_response(_api, _res, SaveQueueComponentSettingsResponse)
