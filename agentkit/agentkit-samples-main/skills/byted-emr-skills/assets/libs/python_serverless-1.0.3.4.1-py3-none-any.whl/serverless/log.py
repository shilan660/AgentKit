from dpquerycore.log import LogCursor
