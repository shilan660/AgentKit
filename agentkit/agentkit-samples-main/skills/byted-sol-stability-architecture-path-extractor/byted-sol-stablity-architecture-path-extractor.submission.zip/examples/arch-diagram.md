# Architecture Diagram Notes (sample)

gateway -> auth-service -> orchestrator -> model-gateway -> tool-gateway -> persistence

async path:
producer -> queue -> worker -> persistence

dependencies:
postgres, redis, kafka, third-party llm api
