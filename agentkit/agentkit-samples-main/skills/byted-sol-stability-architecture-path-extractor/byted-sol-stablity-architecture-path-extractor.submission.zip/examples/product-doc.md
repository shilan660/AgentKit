# Product Doc (sample)

核心用户链路：
- 登录鉴权
- 创建空间
- 创建 agent
- 调用模型
- 执行工具
- 返回结果

控制面链路：
- 配置变更
- 权限校验
- 限流与配额
- 审计

数据面链路：
- 请求入口
- session service
- orchestrator
- model gateway
- tool gateway
- memory retrieval
- sandbox browser
- persistence
