# Copyright (c) 2026 ByteDance
# SPDX-License-Identifier: MIT

from __future__ import annotations

from pathlib import Path

from architecture_path_extractor.pipeline import run_pipeline


def test_pipeline_returns_required_dimensions(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir(parents=True)
    (repo / "docker-compose.yml").write_text("services:\n  gateway:\n    image: g\n", encoding="utf-8")
    (repo / "package.json").write_text('{"dependencies":{"redis":"1.0.0"}}', encoding="utf-8")

    model = run_pipeline(str(repo), product_docs=[], arch_diagrams=[])

    data = model.to_dict()
    assert "service_graph" in data
    assert "request_paths" in data
    assert "async_paths" in data
    assert "dependency_graph" in data
    assert "failure_points" in data
    assert "observability_hook_points" in data
