# Copyright (c) 2026 ByteDance
# SPDX-License-Identifier: MIT

from __future__ import annotations

from pathlib import Path

from architecture_path_extractor.extractors.api_parser import parse_api_signals
from architecture_path_extractor.extractors.config_parser import parse_config_signals
from architecture_path_extractor.extractors.dependency_parser import parse_dependency_signals


def test_config_parser_extracts_services(tmp_path: Path) -> None:
    f = tmp_path / "docker-compose.yml"
    f.write_text("services:\n  gateway:\n    image: g\n  worker:\n    image: w\n", encoding="utf-8")
    signals = parse_config_signals([f])
    values = {x.value for x in signals if x.kind == "service"}
    assert "gateway" in values
    assert "worker" in values


def test_api_parser_extracts_routes(tmp_path: Path) -> None:
    f = tmp_path / "routes.ts"
    f.write_text("router.post('/login', handler)\n", encoding="utf-8")
    signals = parse_api_signals([f])
    assert any(x.kind == "api_route" for x in signals)


def test_dependency_parser_extracts_common_deps(tmp_path: Path) -> None:
    f = tmp_path / "package.json"
    f.write_text('{"dependencies":{"redis":"1.0.0","pg":"1.0.0"}}', encoding="utf-8")
    signals = parse_dependency_signals([f])
    values = {x.value for x in signals}
    assert "redis" in values
    assert "pg" in values
