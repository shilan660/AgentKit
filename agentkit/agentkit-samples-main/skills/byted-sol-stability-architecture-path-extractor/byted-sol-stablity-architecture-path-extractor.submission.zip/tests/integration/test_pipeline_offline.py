# Copyright (c) 2026 ByteDance
# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
from pathlib import Path

from architecture_path_extractor.cli import run_cli


def test_cli_generates_all_output_artifacts(tmp_path: Path) -> None:
    fixture_root = Path(__file__).resolve().parent / "fixtures" / "sample_repo"

    docs = tmp_path / "product-doc.md"
    docs.write_text("login auth orchestrator model tool audit", encoding="utf-8")
    diagram = tmp_path / "arch-diagram.md"
    diagram.write_text("gateway -> orchestrator -> model-gateway -> persistence", encoding="utf-8")

    out_dir = tmp_path / "output"
    rc = run_cli(
        [
            "--repo",
            str(fixture_root),
            "--product-doc",
            str(docs),
            "--arch-diagram",
            str(diagram),
            "--out-dir",
            str(out_dir),
            "--offline",
        ]
    )
    assert rc == 0

    children = list(out_dir.iterdir())
    assert len(children) == 1
    run_dir = children[0]

    topology = run_dir / "topology-model.json"
    core_links = run_dir / "core-links.md"
    dep_risk = run_dir / "dependency-risk.md"
    gaps = run_dir / "observability-gaps.md"
    evidence = run_dir / "evidence-index.json"

    assert topology.exists()
    assert core_links.exists()
    assert dep_risk.exists()
    assert gaps.exists()
    assert evidence.exists()

    payload = json.loads(topology.read_text(encoding="utf-8"))
    assert "service_graph" in payload
    assert "request_paths" in payload
    assert "async_paths" in payload
    assert "dependency_graph" in payload
    assert "failure_points" in payload
    assert "observability_hook_points" in payload
