import express from "express";

const router = express.Router();
router.post("/login", (_req, res) => res.json({ ok: true }));
router.post("/create-space", (_req, res) => res.json({ ok: true }));
router.post("/create-agent", (_req, res) => res.json({ ok: true }));

export default router;
